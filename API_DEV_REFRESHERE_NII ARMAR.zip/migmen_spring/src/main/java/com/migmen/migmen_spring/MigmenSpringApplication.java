package com.migmen.migmen_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication
public class MigmenSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(MigmenSpringApplication.class, args);
        pushDataIntoDb();//
    }

    public static  String pushDataIntoDb(){
        try {
            new PushData().call_me();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "OK";
    }

}
