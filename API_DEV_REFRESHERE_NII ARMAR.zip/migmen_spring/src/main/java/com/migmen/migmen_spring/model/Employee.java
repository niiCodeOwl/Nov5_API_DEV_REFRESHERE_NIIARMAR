package com.migmen.migmen_spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employees")
public class Employee {

    private long id;
    private String nodeName;
    private String Content;
    public Employee() {

    }

    public Employee(String nodeName, String Content) {
        this.nodeName = nodeName;
        this.Content = Content;

    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    @Column(name = "node_name")
    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    @Column(name = "node_content")
    public String getContent() {
        return Content;
    }
    public void setContent(String Content) {
        this.Content = Content;
    }

    @Override
    public String toString() {
        return "Employee [id=" + id + ", NodeName=" + nodeName + ", NodeContent=" + Content + "]";
    }

}