package com.migmen.migmen_spring;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class PushData {

    public static int PRETTY_PRINT_INDENT_FACTOR = 4;

    public String call_me() throws Exception {
        String url = "https://www.treasury.gov/ofac/downloads/sdn.xml";
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        // optional default is GET
        con.setRequestMethod("GET");

        //add request header
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        //parse XML file to list of arrays using xml nodes
        System.out.println(response.toString());

        //read XML from the given string
        String xml = response.toString();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(xml));
        Document doc = builder.parse(is);

        //this will return a list of xml tags whose name is `sdnEntry`
        NodeList hiList = doc.getElementsByTagName("sdnEntry");

        // attempt to create sql connection to the postgres db ** local query for testing **
        Connection c = null;
        Statement stmt = null;
        String status = null;
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "");
            if(!c.isClosed()){
                 status = "Connected";
                String cleantable = "TRUNCATE TABLE employees";
                stmt = c.createStatement();
                stmt.executeUpdate(cleantable);
                stmt.close();


                //you can iterate over hiList ---
                for (int i = 0; i < hiList.getLength(); i++) {
                    Node child = hiList.item(i);
                    String name = child.getNodeName();
                    String contents = child.getTextContent();

                    String sql = "INSERT INTO employees(node_name,node_content)VALUES(?,?)";
                    PreparedStatement pstmt = c.prepareStatement(sql);
                    pstmt.setString(1, name);
                    pstmt.setString(2, contents);
                    pstmt.executeUpdate();

                }

            }else{
                status = "could not connect";
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }

        return status;
    }

}